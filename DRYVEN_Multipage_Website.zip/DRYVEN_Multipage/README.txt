DRYVEN MULTI-PAGE WEBSITE PROTOTYPE

UPLOAD INSTRUCTIONS
1. Make a backup of your current public_html folder/files.
2. Extract this ZIP on your computer or use cPanel File Manager > Upload > Extract.
3. Upload ALL files inside the DRYVEN_Multipage folder directly into public_html.
4. Ensure index.html, payments.html, drivers.html, vehicles.html, managers.html, reports.html, settings.html, style.css and script.js are directly inside public_html (not inside another nested folder).
5. Keep the same filenames and folder structure.
6. Visit https://dryvenlogistics.com and test every navigation link.

IMPORTANT
This is a front-end demonstration only. Data is stored in local browser storage on the device used. It is not a secure shared database, has no real login/authentication, and does not verify payments. Do not use it as the official financial or driver record system until backend/database/security/payment integration is completed.

The daily ₦30,000 value is a configurable placeholder based on the previous setup discussion, not a live billing rule.
